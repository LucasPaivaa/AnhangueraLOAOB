    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fundamentos;

import java.util.Scanner;

/**
 *
 * @author aula
 */
public class EntradaSaida {
    public static void main(String[] args) {
        int idade;
        String nome;
            Scanner tec = new Scanner(System.in);
            System.out.println("Digite  Seu nome:");
            nome = tec.nextLine();
            System.out.println("nome :"+ nome);
            System.out.println("Qual é Sua Idade?");
            idade = Integer.parseInt(tec.nextLine());
                System.out.println("A idade do(a)" + nome + "É" + idade +"Anos" );
                System.out.println(Math.pow(2, 3));
            
            
            tec.close();
    }
    
}
