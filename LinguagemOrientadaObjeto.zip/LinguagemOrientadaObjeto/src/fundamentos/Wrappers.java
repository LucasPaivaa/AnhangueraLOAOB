/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fundamentos;

/**
 *
 * @author aula
 */
public class Wrappers {
    public static void main(String[] args) {
        int x = 10;
        Integer z = 10;
      
             
              //System.out.println(x);
              //System.out.println(z);
              
              String y = "20";
              x = Integer.parseInt(y);
              System.out.println(x);
              y = Integer.toString(x);
              
              
              String nome = "Lucas de Paiva Rocha";
              nome = nome.substring(0,5);
              System.out.println("O nome "+ nome.toUpperCase() + nome.length() + "caracteres");
    }
    
}
