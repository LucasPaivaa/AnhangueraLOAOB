//1 - Faça um programa que declare uma variável inteira, inicialize-a com a sua idade e mostre-a.
package fundamentos.Lista01;

import java.util.Scanner;

/**
 *
 * @author aula
 */
public class Atividade1 {
    public static void main(String[] args) {
        
        int idade;
        
        Scanner tec = new Scanner(System.in);
        System.out.println("Digite Sua Idade:");
        idade = tec.nextInt();
        System.out.println("Sua idade é " + idade);
        
        tec.close();
        
    }
}
