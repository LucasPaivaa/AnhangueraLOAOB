//2 - Ler os valores de comprimento, largura e altura e apresentar o valor do volume de uma caixa retangular. Utilize para o cálculo a formula
//Volume = comprimento * largura * altura

package fundamentos.Lista01;

import java.util.Scanner;


public class Atividade2 {
    public static void main(String[] args) {
        int comprimento, largura, altura, volume;
        
         Scanner ent = new Scanner(System.in);
             System.out.println("Digite o Comprimento:");
         comprimento = ent.nextInt();
             System.out.println("Agora Digite a Largura:");
         largura = ent.nextInt();
             System.out.println("Digite a Altura:");
      
         altura = ent.nextInt();
         
         volume = comprimento * largura * altura;
        
             System.out.println("O Volume é: " + volume);
         ent.close();
        

    }
}
