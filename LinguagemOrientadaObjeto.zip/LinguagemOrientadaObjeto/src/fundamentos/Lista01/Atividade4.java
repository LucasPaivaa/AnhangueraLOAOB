/*4 - Receba a altura e a largura e a partir dessa informação calcule a área o e perímetro de um retângulo, onde:
área = base * altura
perímetro = 2base + 2altura
*/
package fundamentos.Lista01;

import java.util.Scanner;

/**
 *
 * @author lucas.paiva
 */
public class Atividade4 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        
        int base, altura, perimetro, area;
        
        System.out.println("Digite sua base:");
        base = ent.nextInt();
        System.out.println("Digite sua altura:");
        altura = ent.nextInt();
        
        area = base * altura;
        perimetro = (2*base) + (2*altura);
        
        System.out.println("Sua area é: " + area);
        System.out.println("O perimetro é :" + perimetro);
        ent.close();
    }
}
