/*6 – Desenvolver um programa utilizando os conceitos de variáveis para resolver a expressão matemática abaixo sendo que o resultado é 125.*/
package fundamentos.Lista01;

import java.util.Scanner;

public class Atividade6 {
    public static void main(String[] args) {
         
        int a,b,c,d,e, f, g, h, i, j, k,l, m ;
       
        
        a = 6*(3+2);
        b = (int) Math.pow(a, 2);
        System.out.println(b);
        
        c = 3*2;
        d = b/c;
        System.out.println(d);
        
        e = 1-5;
        f = 2-7;
        g = e * f;
        h = (int) Math.pow(g, 2);
        System.out.println(h);
        
        i = h/2;
        System.out.println();
         j = d - i;
          System.out.println(j);
          k = (int) Math.pow(j, 3);
          
          System.out.println(k);
         
         l = (int ) Math.pow(10, 3);
         
         System.out.println(l);
         
         m = k/l;
         
       System.out.println(m);
        
        
        
        
    }
   
}
