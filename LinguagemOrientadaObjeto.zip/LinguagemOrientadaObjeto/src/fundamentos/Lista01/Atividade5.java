/*5 - Ler uma temperatura em graus centigradis e apresenta-lá convertida em graus fahrenheit.
A formula de conversao é: F + (9*C+160)/5. Onde F é a temperatura em faherenheit 
e C é a temperatura em centigrados.
*/
package fundamentos.Lista01;

import java.util.Scanner;


public class Atividade5 {
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        int C, F;
        
                
         System.out.println("Digite Quantos Graus °C: ");
        C  = ent.nextInt();
        //F =(C * 9/5)+32;
        F = (9* C + 160)/5; 
        
        System.out.println("Sua Temperatura em Fahrenheit é:" + F);
        
        
            ent.close();
        
    }
}
