/* 3 - Efetuar o cálculo da quantidade de litros de combustível gasta em uma viagem, utilizando um automóvel que faz 12km por litro. Para obter o cálculo o usuário deve fornece o tempo gasto na viagem e a velocidade média durante ela.
Dessa forma será possível obter a distância percorrida com a fórmula
DISTANCIA = TEMPO * VELOCIDADE
Tendo o valor da distância basta calcular a quantidade de litros de combustível utilizada na viagem com a fórmula
LITROS_USADOS = DISTANCIA /12
O programa deve apresentar os valores da velocidade média, tempo gasto da viagem, a distância percorrida e a quantidade de litros utilizada.

*/
package fundamentos.Lista01;

import java.util.Scanner;


public class Atividade3 {
     public static void main(String[] args) {
            
         int distancia, tempo, velocidade; 
         
         Scanner ent = new Scanner(System.in);
         
        
    }
    
}
