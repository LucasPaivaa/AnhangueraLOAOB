/* 3 - Efetuar o cálculo da quantidade de litros de combustível gasta em uma viagem, utilizando um automóvel que faz 12km por litro. Para obter o cálculo o usuário deve fornece o tempo gasto na viagem e a velocidade média durante ela.
Dessa forma será possível obter a distância percorrida com a fórmula
DISTANCIA = TEMPO * VELOCIDADE
Tendo o valor da distância basta calcular a quantidade de litros de combustível utilizada na viagem com a fórmula
LITROS_USADOS = DISTANCIA /12
O programa deve apresentar os valores da velocidade média, tempo gasto da viagem, a distância percorrida e a quantidade de litros utilizada.

*/
package fundamentos.Lista01;

import java.util.Scanner;


public class Atividade3 {
     public static void main(String[] args) {
            
         double VelocidadeMedia, TempoGasto, Autonomia = 12;
         double distancia, LitrosUsados; 
         
         Scanner ent = new Scanner(System.in);
             System.out.print("Programa de cálculo da quantidade de litro4s de combustível gasta em uma viagem\n\n");
         
             System.out.println("Digite o seu tempo Gasto em sua viagem(horas):");
         TempoGasto = ent.nextDouble();
         
             System.out.println("Agora Digite Sua velocidade media(km/h):");
         
         VelocidadeMedia = ent.nextDouble();
             
             distancia = TempoGasto * VelocidadeMedia;
             LitrosUsados = distancia/ Autonomia;
             
         System.out.println("\n\nResultados:\n\n");
         System.out.println("Sua Velocidade Média = "+ VelocidadeMedia + " km/h\n");
         System.out.print("Tempo gasto = " + TempoGasto + " horas\n");
         System.out.print("Distancia Percorrida = " + distancia + " Km\n");
	 System.out.print("Quantidade de Combustível utilizado: " + LitrosUsados + " litros\n");

         
       
    }
    
}
