
package fundamentos;

/**
 *
 * @author aula
 */
public class Variaveis {
    public static void main(String[] args) {
        byte b = 127;
        short sh = 100;
        int i = 1000;
        long lo = 10000;
        
        sh = b;
        b = (byte)sh;
        
        float fl = 10.0f;
        
        double doub = 10.5;
        
        char ch = 'a';
        
        boolean bo = 6>3;
        System.out.println(bo);
        
        //inferência de tipos
        
        int x = 10;
         System.out.println(x);
        
    }
    
    
}
