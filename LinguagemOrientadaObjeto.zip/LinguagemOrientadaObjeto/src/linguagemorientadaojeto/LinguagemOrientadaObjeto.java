
package linguagemorientadaojeto;

public class LinguagemOrientadaObjeto {

    
    public static void main(String[] args) {
        System.out.println("Olá Mundo!");
    }
    
}
